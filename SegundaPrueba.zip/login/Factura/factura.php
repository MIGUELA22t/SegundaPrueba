<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Venta</title>
    <link rel="stylesheet" href="css/cssIndex.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>
<body>
  <div class="container">
    <div class="row">
      <div class="col-md-4">
        <div id="formulario">
          <form id="ini" action="Crud/nuevaFactura.php" method="POST">
            <input class="btn btn-secondary" type="submit" value="Nueva"/>
          </form>

          <form action="Crud/insertar.php" method="POST">
            <div><h2>Factura</h2></div>
            <div id="content">
              <input class="form-control" id="nombre" name="nombre" type="text" required placeholder="Producto..." /> <br>
              <input class="form-control" id="precio" name="precio" type="text" onkeyup="format(this)" onchange="format(this)" required placeholder="Precio..." /> <br>
              <input class="form-control" id="cantidad" name="cantidad" type="number" required placeholder="Cantidad..." /> <br>
              <input class="btn btn-success" id="boton1" name="enviar" type="submit" value="Enviar" />
            </div>
          </form>
          
          <div class="mt-3">
            <a class="btn btn-sm btn-danger btn-block" id="botonSalir" href="../login_users/home.php">Salir</a>
          </div>
        </div>
      </div>

      <?php
        if(isset($_GET['redirect']) && $_GET['redirect'] === 'home') {
          header("Location: ./login_users/home.php");
          exit;
        }

        include_once "Views/listaIndex.php";
      ?>
    </div>
  </div>
</body>
</html>
