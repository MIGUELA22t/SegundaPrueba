
function imprimir() {
  window.print();
}