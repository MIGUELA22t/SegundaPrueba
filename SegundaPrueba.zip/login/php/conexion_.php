<?php

$conexion = mysqli_connect(
    "localhost",
    "root", 
    "",
    "login_register_db"
);

// PARA SABER SI FUNCIONA EL localhost
    // if($conexion){
    //     echo 'Conectado exitosamente a la Base de datos';
    // } else{
    //     echo 'ERROR';
 //}


?>