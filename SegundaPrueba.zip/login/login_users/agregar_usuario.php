<?php
session_start();
include "db_conn.php";

if ($_SESSION['role'] != 'admin') {
    header("Location: index.php");
    exit();
}

// Manejar el formulario para agregar usuarios
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newName = $_POST['new_name'];
    $newUsername = $_POST['new_username'];
    $newPassword = $_POST['new_password'];
    $newRole = $_POST['new_role'];

    $insertResult = insertUser($newName, $newUsername, $newPassword, $newRole);

    if ($insertResult) {
        // Redirige a la página de inicio o muestra un mensaje de éxito
        header("Location: home.php");
        exit();
    } else {
        echo "Error al agregar el usuario. Por favor, intenta de nuevo.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Agregar Usuario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .card {
            width: 18rem;
            margin-right: 20px;
        }
        form {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <img src="img/admin-default.png" class="card-img-top" alt="admin image">
            <div class="card-body text-center">
                <h5 class="card-title"><?php echo $_SESSION['name']; ?></h5>
                <a href="logout.php" class="btn btn-dark">Logout</a>
                <a href="/login/Factura/factura.php" class="btn btn-primary">Facturación</a>
                <a href="agregar_usuario.php" class="btn btn-success">Agregar Usuario</a>
            </div>
        </div>
        <div>
            <h1>Agregar Nuevo Usuario</h1>
            <form method="POST" action="">
                <input type="text" name="new_name" placeholder="Nombre" class="form-control"><br>
                <input type="text" name="new_username" placeholder="Nombre de Usuario" class="form-control"><br>
                <input type="password" name="new_password" placeholder="Contraseña" class="form-control"><br>
                <label>Rol:</label><br>
                <input type="radio" name="new_role" value="admin"> Admin<br>
                <input type="radio" name="new_role" value="user"> User<br>
                <input type="submit" name="submit" value="Agregar" class="btn btn-primary">
            </form>
        </div>
    </div>
</body>
</html>
