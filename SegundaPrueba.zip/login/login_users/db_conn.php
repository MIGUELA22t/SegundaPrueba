<?php
$sname = "localhost";
$uname = "root";
$password = "";
$db_name = "my_db";

$conn = mysqli_connect($sname, $uname, $password, $db_name);

if (!$conn) {
    echo "Connection Failed!";
    exit();
}

function insertUser($name, $username, $password, $role) {
    global $conn;

    $name = mysqli_real_escape_string($conn, $name);
    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);
    $role = mysqli_real_escape_string($conn, $role);

    // Hashing the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $insertQuery = "INSERT INTO users (name, username, password, role) VALUES ('$name', '$username', '$hashedPassword', '$role')";
    $result = mysqli_query($conn, $insertQuery);

    return $result;
}
?>
